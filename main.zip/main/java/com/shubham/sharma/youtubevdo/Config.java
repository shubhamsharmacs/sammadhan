package com.shubham.sharma.youtubevdo;

/**
 * Created by echessa on 7/17/15.
 */
public final class Config {

    private Config() {
    }
/////									///////			AIzaSyA_2Ctrkp-EhrbmXq8lZ1lvKT4RT1Kadpc
    public static final String YOUTUBE_API_KEY = "AIzaSyA_2Ctrkp-EhrbmXq8lZ1lvKT4RT1Kadpc";

}